export const DB_CONFIG = {
    apiKey: "AIzaSyAZpgdX6LLrExqj_V60w3isssA3uPjCbrs",
    authDomain: "testing2-b8491.firebaseapp.com",
    databaseURL: "https://testing2-b8491.firebaseio.com",
    projectId: "testing2-b8491",
    storageBucket: "testing2-b8491.appspot.com",
    messagingSenderId: "318873078873",
    appId: "1:318873078873:web:34e14b1b0f68116839b548",
    measurementId: "G-297VZ0GJ3W"
  };
